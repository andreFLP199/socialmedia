-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema social_media
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema social_media
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `social_media` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `social_media` ;

-- -----------------------------------------------------
-- Table `social_media`.`amigo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_media`.`amigo` (
  `idAutor` INT NOT NULL,
  `idAmigo` INT NOT NULL,
  PRIMARY KEY (`idAutor`, `idAmigo`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `social_media`.`comentario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_media`.`comentario` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `idPost` INT NULL DEFAULT NULL,
  `idAutor` INT NULL DEFAULT NULL,
  `data` DATETIME NULL DEFAULT NULL,
  `texto` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `social_media`.`like`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_media`.`like` (
  `idAutor` INT NOT NULL,
  `idPost` INT NOT NULL,
  PRIMARY KEY (`idAutor`, `idPost`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `social_media`.`mensagem`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_media`.`mensagem` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `data` DATETIME NULL DEFAULT NULL,
  `texto` TEXT NULL DEFAULT NULL,
  `idAutor` INT NULL DEFAULT NULL,
  `idTarget` INT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `social_media`.`pedido_amizade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_media`.`pedido_amizade` (
  `idAutor` INT NOT NULL,
  `idTarget` INT NOT NULL,
  PRIMARY KEY (`idAutor`, `idTarget`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `social_media`.`post`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_media`.`post` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `restricao` INT NULL DEFAULT '0',
  `idAutor` INT NULL DEFAULT NULL,
  `data` DATETIME NULL DEFAULT NULL,
  `texto` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `social_media`.`utilizador`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_media`.`utilizador` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `perfilRestricao` INT NULL DEFAULT '0',
  `username` VARCHAR(45) NULL DEFAULT NULL,
  `password` VARCHAR(45) NULL DEFAULT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `nome` VARCHAR(45) NULL DEFAULT NULL,
  `telefone` VARCHAR(45) NULL DEFAULT NULL,
  `morada` VARCHAR(45) NULL DEFAULT NULL,
  `idade` INT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 7
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
